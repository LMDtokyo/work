namespace MessagingPlatform.Domain.Enums;

public enum WbAccountStatus
{
    Active,
    Inactive,
    TokenExpired,
    Error
}
