namespace MessagingPlatform.Domain.Enums;

public enum UserRole
{
    User = 0,
    Admin = 1,
    SuperAdmin = 2
}
