namespace MessagingPlatform.Domain.Enums;

public enum ThemePreference
{
    Dark = 0,
    Light = 1
}
