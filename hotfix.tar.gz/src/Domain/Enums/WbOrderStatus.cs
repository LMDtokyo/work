namespace MessagingPlatform.Domain.Enums;

public enum WbOrderStatus
{
    New,
    Confirmed,
    Assembled,
    Shipped,
    Delivered,
    Cancelled
}
