export type TransactionType = "red" | "green" | "yellow";

export interface Transaction {
  id: string;
  title: string;
  platform: string;
  sum: number;
  date: string;
}

export const mockTransactions: Transaction[] = [
  {
    id: "1",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "2",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "3",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "4",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "5",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "6",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "7",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "8",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "9",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "10",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "11",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "12",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "13",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "14",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
  {
    id: "15",
    title: "Продажа: Смартфон Samsung Galaxy",
    platform: "Wildberries",
    sum: 45990,
    date: "15 янв. 2024 г., 14:30",
  },
];
