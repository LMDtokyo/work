export interface IRecoveryPasswordForm {
  email: string;
  password: string;
  repeatPassword: string;
}
