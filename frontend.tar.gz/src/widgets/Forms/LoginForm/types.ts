export interface LoginFormData {
  email: string;
  password: string;
}
