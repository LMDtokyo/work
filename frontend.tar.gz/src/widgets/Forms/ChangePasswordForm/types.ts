export interface IChangePasswordForm {
  currentPassword: string;
  newPassword: string;
  repeatPassword: string;
}
